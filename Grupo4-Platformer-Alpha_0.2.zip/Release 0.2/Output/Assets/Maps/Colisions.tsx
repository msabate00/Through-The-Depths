<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.1" name="Colisions" tilewidth="16" tileheight="16" tilecount="8" columns="4">
 <image source="MapMetadata.png" width="67" height="34"/>
</tileset>
